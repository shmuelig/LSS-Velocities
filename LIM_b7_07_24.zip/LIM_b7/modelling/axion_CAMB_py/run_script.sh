#/bin/bash

cd axion_CAMB_py/axionCAMB-master
./camb ../input_params.ini
